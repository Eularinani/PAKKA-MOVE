package com.example.PAKA_MOVE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PakaMoveApplicationTests {

	@Test
	void contextLoads() {
	}

}
