package com.example.PAKA_MOVE.Controllers;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.PAKA_MOVE.models.Usuario;
import com.example.PAKA_MOVE.Repository.UsuarioRepository;
@RestController
@RequestMapping(path = "/api/usuarios") 
public class UsuarioController {

    //o codigo abaixodevolve um grupo de coisa
private Logger logger = LoggerFactory.getLogger(UsuarioController.class);
@Autowired
private UsuarioRepository UsuarioRepository;
@GetMapping(path = "", produces = MediaType.APPLICATION_JSON_VALUE) public Iterable<Usuario> getUsuario() {
logger.info("Sending all Usuario");
return UsuarioRepository.findAll(); }



}
