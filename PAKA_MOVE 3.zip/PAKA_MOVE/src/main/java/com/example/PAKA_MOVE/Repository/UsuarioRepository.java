package com.example.PAKA_MOVE.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.PAKA_MOVE.models.Usuario;

public interface UsuarioRepository extends CrudRepository <Usuario,Integer>{
    
}