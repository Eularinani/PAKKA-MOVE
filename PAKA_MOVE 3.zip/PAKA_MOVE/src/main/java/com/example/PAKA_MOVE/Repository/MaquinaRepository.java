package com.example.PAKA_MOVE.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.PAKA_MOVE.models.Maquina;


public interface MaquinaRepository extends CrudRepository<Maquina,Integer> {  
   
}