package com.example.PAKA_MOVE.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.PAKA_MOVE.models.TipoMac;

public  interface TipoMacRepository extends CrudRepository<TipoMac,Integer> { 

    @Query(value="select tipo_mac_nome from tipo_mac where tipo_mac_nome =':name' ",nativeQuery = true)
    Iterable<TipoMac>tipomac(@Param("name") String name);

}


