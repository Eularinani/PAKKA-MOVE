package com.example.PAKA_MOVE.models;

public class Maquina {
    private int id_maquina;
    
}
