package com.example.PAKA_MOVE.models;

public class User {
    private static int nextNumber = 0; 
    private String name; 
    private String email; 
    private char gender; 
    private int number; 
    
}
