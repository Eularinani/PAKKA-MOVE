package com.example.PAKA_MOVE.models;

import java.time.LocalDate;

public class Estado {
     int id_estado; 
    private String nome; 
    private LocalDate momento; 

    Estado(int Identificção,String nome,LocalDate momento){
        id_estado = Identificção;
        this.nome = nome;
        this.momento = momento;


    }
    
}
