package com.example.PAKA_MOVE.models;

public class Local {
    int Id_local;
    private String Endereco;
    private int Codigo_Postal;
    private int Cordenadas_geograficas;

    Local(int Id_local,String Endereço,int C_P , int C_G){
        this.Id_local = Id_local;
        Endereco = Endereço;
        Codigo_Postal = C_P;
        Cordenadas_geograficas = C_G;


    }
}
