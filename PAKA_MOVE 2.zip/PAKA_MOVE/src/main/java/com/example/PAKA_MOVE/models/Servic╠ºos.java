package com.example.PAKA_MOVE.models;

public class Serviços {
    int Id_ser;
    private String Tipo_Serv ;
    private String direcionado;

    Serviços(int Serv,String Tipos,String direcionado){
        Id_ser = Serv;
        Tipo_Serv = Tipos;
        this.direcionado = direcionado;

    }
    
}
